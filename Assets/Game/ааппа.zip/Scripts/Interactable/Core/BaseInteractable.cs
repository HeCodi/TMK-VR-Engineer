using Assets.Game.Scripts.Interactable.Core;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace Assets.Game.Scripts.Interactable.Core
{
    [RequireComponent(typeof(XRGrabInteractable))]
    public class BaseInteractable : MonoBehaviour
    {
        private XRGrabInteractable _grabInteractable;
        private InteractionContext _context;

        public InteractionContext Context => _context;

        protected virtual void Awake()
        {
            _grabInteractable = GetComponent<XRGrabInteractable>();

            _context = new InteractionContext(
                transform,
                _grabInteractable);

            _grabInteractable.selectEntered.AddListener(OnSelectEntered);
            _grabInteractable.selectExited.AddListener(OnSelectExited);
        }

        protected virtual void OnDestroy()
        {
            _grabInteractable.selectEntered.RemoveListener(OnSelectEntered);
            _grabInteractable.selectExited.RemoveListener(OnSelectExited);
        }

        private void OnSelectEntered(SelectEnterEventArgs args)
        {
            _context.AddInteractor(args.interactorObject);
        }

        private void OnSelectExited(SelectExitEventArgs args)
        {
            _context.RemoveInteractor(args.interactorObject);
        }
    }
}