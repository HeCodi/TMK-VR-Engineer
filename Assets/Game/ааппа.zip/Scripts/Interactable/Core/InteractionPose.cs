﻿using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Core
{
    public readonly struct InteractionPose
    {
        public readonly Vector3 Position;
        public readonly Quaternion Rotation;

        public InteractionPose(
            Vector3 position,
            Quaternion rotation)
        {
            Position = position;
            Rotation = rotation;
        }

        public Pose ToPose()
        {
            return new Pose(Position, Rotation);
        }
    }
}