﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace Assets.Game.Scripts.Interactable.Core
{
    public class InteractionContext
    {
        private readonly List<IXRInteractor> _interactors = new();

        private readonly Transform _transform;
        private readonly IXRInteractable _interactable;

        public InteractionContext(
            Transform transform,
            IXRInteractable interactable)
        {
            _transform = transform;
            _interactable = interactable;
        }

        public IReadOnlyList<IXRInteractor> Interactors => _interactors;

        public Transform Transform => _transform;

        public int Count => _interactors.Count;

        public void AddInteractor(
            IXRInteractor interactor)
        {
            if (!_interactors.Contains(interactor))
                _interactors.Add(interactor);
        }

        public void RemoveInteractor(
            IXRInteractor interactor)
        {
            _interactors.Remove(interactor);
        }

        public Transform GetAttachTransform(
            IXRInteractor interactor)
        {
            return interactor.GetAttachTransform(_interactable);
        }

        public InteractionPose GetInteractionPose()
        {
            switch (Count)
            {
                case 0:
                    return new InteractionPose(
                        _transform.position,
                        _transform.rotation);

                case 1:
                    return GetSingleHandPose();

                default:
                    return GetTwoHandPose();
            }
        }

        private InteractionPose GetSingleHandPose()
        {
            Transform hand =
                GetAttachTransform(_interactors[0]);

            return new InteractionPose(
                hand.position,
                hand.rotation);
        }

        private InteractionPose GetTwoHandPose()
        {
            Transform first =
                GetAttachTransform(_interactors[0]);

            Transform second =
                GetAttachTransform(_interactors[1]);

            Vector3 center =
                (first.position + second.position) * 0.5f;

            Vector3 direction =
                second.position - first.position;

            Quaternion rotation =
                Quaternion.LookRotation(
                    direction.normalized,
                    _transform.up);

            return new InteractionPose(
                center,
                rotation);
        }
    }
}