﻿using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Core
{
    [RequireComponent(typeof(BaseInteractable))]
    public abstract class BaseInteraction : MonoBehaviour
    {
        private BaseInteractable _interactable;

        protected BaseInteractable Interactable => _interactable;

        protected InteractionContext Context => _interactable.Context;

        protected virtual void Awake()
        {
            _interactable = GetComponent<BaseInteractable>();
        }
    }
}