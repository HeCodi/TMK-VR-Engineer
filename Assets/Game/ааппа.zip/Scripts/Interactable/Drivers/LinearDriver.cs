﻿using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Drivers
{
    public class LinearDriver : BaseDriver
    {
        [SerializeField] private Transform _target;

        [SerializeField] private Transform _start;

        [SerializeField] private Transform _end;

        protected override void OnValueChanged(float value)
        {
            _target.position = Vector3.Lerp(
                _start.position,
                _end.position,
                value);

            _target.rotation = Quaternion.Lerp(
                _start.rotation,
                _end.rotation,
                value);
        }
    }
}