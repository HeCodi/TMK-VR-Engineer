﻿using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Drivers
{
    public class RotationDriver : BaseDriver
    {
        [SerializeField] private Transform _target;

        [SerializeField] private Vector3 _axis = Vector3.up;

        [SerializeField] private float _minAngle = -90f;
        [SerializeField] private float _maxAngle = 90f;

        protected override void OnValueChanged(float value)
        {
            float angle = Mathf.Lerp(
                _minAngle,
                _maxAngle,
                value);

            _target.localRotation =
                Quaternion.AngleAxis(
                    angle,
                    _axis);
        }
    }
}