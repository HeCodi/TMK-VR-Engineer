using Assets.Game.Scripts.Interactable.Interaction;
using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Drivers
{
    public abstract class BaseDriver : MonoBehaviour
    {
        [SerializeField] private BaseValueInteraction _interaction;

        protected virtual void Awake()
        {
            _interaction.ValueChanged += OnValueChanged;
            OnValueChanged(_interaction.Value);
        }

        protected virtual void OnDestroy()
        {
            if (_interaction != null)
                _interaction.ValueChanged -= OnValueChanged;
        }

        protected abstract void OnValueChanged(float value);
    }
}