﻿using System;
using Assets.Game.Scripts.Interactable.Core;
using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Interaction
{
    public abstract class BaseValueInteraction : BaseInteraction
    {
        [SerializeField] protected float _minValue = 0f;
        [SerializeField] protected float _maxValue = 1f;

        [SerializeField]
        private float _value;

        public float Value => _value;

        public event Action<float> ValueChanged;

        protected virtual void Update()
        {
            if (Context.Interactors.Count == 0)
                return;

            float value = CalculateValue();

            value = Mathf.Clamp(value, _minValue, _maxValue);

            if (Mathf.Approximately(value, _value))
                return;

            _value = value;

            OnValueChanged(_value);

            ValueChanged?.Invoke(_value);
        }

        protected void SetValue(float value)
        {
            value = Mathf.Clamp(value, _minValue, _maxValue);

            if (Mathf.Approximately(value, _value))
                return;

            _value = value;

            OnValueChanged(_value);

            ValueChanged?.Invoke(_value);
        }

        protected virtual void OnValueChanged(float value)
        {

        }

        protected abstract float CalculateValue();
    }
}