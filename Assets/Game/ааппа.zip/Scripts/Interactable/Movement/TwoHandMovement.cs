﻿using Assets.Game.Scripts.Interactable.Core;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace Assets.Game.Scripts.Interactable.Movement
{
    public class TwoHandMovement
    {
        private bool _initialized;

        private Vector3 _localPositionOffset;
        private Quaternion _localRotationOffset;

        private IXRInteractor _firstInteractor;
        private IXRInteractor _secondInteractor;

        public Pose Solve(InteractionContext context)
        {
            IXRInteractor first = context.Interactors[0];
            IXRInteractor second = context.Interactors[1];

            if (!_initialized ||
                _firstInteractor != first ||
                _secondInteractor != second)
            {
                Initialize(context, first, second);
            }

            Transform firstAttach =
                context.GetAttachTransform(first);

            Transform secondAttach =
                context.GetAttachTransform(second);

            Vector3 direction =
                secondAttach.position - firstAttach.position;

            if (direction.sqrMagnitude < 0.000001f)
            {
                return new Pose(
                    context.Transform.position,
                    context.Transform.rotation);
            }

            Quaternion rotation =
                Quaternion.LookRotation(
                    direction.normalized,
                    context.Transform.up);

            Vector3 position =
                firstAttach.position +
                rotation * _localPositionOffset;

            rotation *= _localRotationOffset;

            return new Pose(position, rotation);
        }

        private void Initialize(
            InteractionContext context,
            IXRInteractor first,
            IXRInteractor second)
        {
            Transform firstAttach =
                context.GetAttachTransform(first);

            Transform secondAttach =
                context.GetAttachTransform(second);

            Vector3 direction =
                secondAttach.position - firstAttach.position;

            if (direction.sqrMagnitude < 0.000001f)
                return;

            Quaternion rotation =
                Quaternion.LookRotation(
                    direction.normalized,
                    context.Transform.up);

            _localPositionOffset =
                Quaternion.Inverse(rotation) *
                (context.Transform.position - firstAttach.position);

            _localRotationOffset =
                Quaternion.Inverse(rotation) *
                context.Transform.rotation;

            _firstInteractor = first;
            _secondInteractor = second;

            _initialized = true;
        }

        public void Reset()
        {
            _initialized = false;

            _firstInteractor = null;
            _secondInteractor = null;
        }
    }
}