﻿using Assets.Game.Scripts.Interactable.Core;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace Assets.Game.Scripts.Interactable.Movement
{
    public class OneHandMovement
    {
        private bool _initialized;

        private Vector3 _localPositionOffset;
        private Quaternion _localRotationOffset;

        private IXRInteractor _currentInteractor;

        public Pose Solve(InteractionContext context)
        {
            IXRInteractor interactor = context.Interactors[0];

            if (!_initialized || _currentInteractor != interactor)
            {
                Initialize(context, interactor);
            }

            Transform attach =
                context.GetAttachTransform(interactor);

            Vector3 position =
                attach.position +
                attach.rotation * _localPositionOffset;

            Quaternion rotation =
                attach.rotation *
                _localRotationOffset;

            return new Pose(position, rotation);
        }

        private void Initialize(
            InteractionContext context,
            IXRInteractor interactor)
        {
            Transform attach =
                context.GetAttachTransform(interactor);

            _localPositionOffset =
                Quaternion.Inverse(attach.rotation) *
                (context.Transform.position - attach.position);

            _localRotationOffset =
                Quaternion.Inverse(attach.rotation) *
                context.Transform.rotation;

            _currentInteractor = interactor;
            _initialized = true;
        }

        public void Reset()
        {
            _initialized = false;
            _currentInteractor = null;
        }
    }
}