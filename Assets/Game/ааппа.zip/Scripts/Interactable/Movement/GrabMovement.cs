﻿using Assets.Game.Scripts.Interactable.Core;
using UnityEngine;

namespace Assets.Game.Scripts.Interactable.Movement
{
    [RequireComponent(typeof(BaseInteractable))]
    public class GrabMovement : MonoBehaviour
    {
        [SerializeField] private MovementMode _movementMode = MovementMode.Auto;

        private BaseInteractable _interactable;
        private InteractionContext _context;

        private readonly OneHandMovement _oneHandMovement = new();
        private readonly TwoHandMovement _twoHandMovement = new();

        private int _lastInteractorCount = -1;

        private void Awake()
        {
            _interactable = GetComponent<BaseInteractable>();
            _context = _interactable.Context;
        }

        private void LateUpdate()
        {
            int currentInteractorCount = _context.Interactors.Count;

            if (currentInteractorCount == 0)
            {
                _lastInteractorCount = 0;
                return;
            }

            if (_lastInteractorCount != currentInteractorCount)
            {
                _oneHandMovement.Reset();
                _twoHandMovement.Reset();

                _lastInteractorCount = currentInteractorCount;
            }

            Pose targetPose = GetTargetPose();

            transform.SetPositionAndRotation(
                targetPose.position,
                targetPose.rotation);
        }

        private Pose GetTargetPose()
        {
            switch (_movementMode)
            {
                case MovementMode.OneHandOnly:
                    return _oneHandMovement.Solve(_context);

                case MovementMode.TwoHandOnly:
                    if (_context.Interactors.Count < 2)
                        return new Pose(transform.position, transform.rotation);

                    return _twoHandMovement.Solve(_context);

                case MovementMode.Auto:
                default:
                    if (_context.Interactors.Count == 1)
                        return _oneHandMovement.Solve(_context);

                    return _twoHandMovement.Solve(_context);
            }
        }
    }

    public enum MovementMode
    {
        Auto,
        OneHandOnly,
        TwoHandOnly
    }
}